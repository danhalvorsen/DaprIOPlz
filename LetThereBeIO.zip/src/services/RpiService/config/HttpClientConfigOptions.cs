﻿namespace RpiService.config {

	public class HttpClientConfigOptions {
		public static string HttpClientConfig => "HttpClientConfig";
	}

}
