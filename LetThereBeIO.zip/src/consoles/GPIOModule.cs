﻿public interface GPIOModule {
  public void Command();
}
