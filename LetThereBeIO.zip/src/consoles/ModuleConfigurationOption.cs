﻿
public class ModuleConfigurationOption {
    public const string Module = nameof(TheModuleConfiguration);
}
