﻿
#region configuration
//https://learn.microsoft.com/en-us/dotnet/core/extensions/options-library-authors

public class TheModuleConfiguration {
    public string? Foo { get; set; }
    public string? Bar { get; set; }
}
#endregion