﻿namespace RpiService.controllers.pubsub {
	public class IOState {

		public int Pin { get; set; }
		public bool State { get; set; }
	}
}
